package com.repository;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.entity.Student;
import com.entity.Passport;
import com.entity.*;
@Repository
@Transactional
public class StudentRepository {	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;
	
	public Student findById(Long id){
		return em.find(Student.class, id);
	}
	public Student save(Student student) {
		if(student.getId()==null) {
			em.persist(student);
		}
		else {
			em.merge(student);
			
		}
		return student;
	}

	
	//public Student save(Student student) -> insert or update
	
	public void deleteById(Long id) {
		Student student=findById(id);
		em.remove(student);
	}

	
	
	public void saveStudentWithPassport() {
		Passport passport =new Passport("Z123456");
		em.persist(passport);
		
		Student student= new Student("Mike");
		student.setPassport(passport);
		em.persist(student);
}
		
	

	public void someOperationToUnderstandPersistenceContext() {
		//Retrieve Student details
		Student student = em.find(Student.class,20001L);
		//Persistence Context(student)
		
		
		//Retriieve  passport
		Passport passport=student.getPassport();
		//Persistence Context(student,passport)
		
		//Update passport
		passport.setNumber("E123457");
		//Persistence Context(student,passport++)
		
		
		//update student details
		student.setName("Ranga - updated");
		//Persistence Context(student++,passport++)
	}
	
	public void insertHardcodedStudentAndCourse() {
		Student student=new Student("siva");
		Course course=new Course("Microservices in 100 steps");
		em.persist(student);
		em.persist(course);
		
		student.addCourse(course);
		course.addStudent(student);
		em.persist(student);
		
	}
	public void insertStudentAndCourse(Student student,Course course) {
		//Student student=new Student("siva");
		//Course course=new Course("Microservices in 100 steps");
		student.addCourse(course);
		course.addStudent(student);
		
		em.persist(student);
		em.persist(course);
		
	
		em.persist(student);
		
	}
         // Student student2 = findById(10001L);
		
		//student2.setName("JPA in 50 Steps - Updated");
		
		
		
		
		//student1.setName(null);
		
		
		//em.persist(student1);
		//em.flush();
		
		//Student student2 = new Student("Angular Js in 100 steps");
		//em.persist(student2);
		
		//em.flush();
		
		//em.detach(student1);
		//em.detach(student2);
		//em.clear();
		
		//em.flush();
		//student1.setName("Web Services in 100 steps - Updated");
		//student2.setName("Angular Js in 100 steps - Updated");
		//em.refresh(student1);
		//em.flush();
	}

