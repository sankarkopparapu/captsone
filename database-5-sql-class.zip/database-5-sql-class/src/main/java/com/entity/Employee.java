package com.entity;
import java.time.LocalDateTime;
import com.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.List;
import java.util.ArrayList;
@Entity

public abstract class Employee {

	@Id
	@GeneratedValue
	private Long id;

	@Column(nullable=false)
	private String name;

	protected Employee() {
	}

	

	public Employee(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}
	@Override
	public String toString() {
		return String.format("\nEmployee [id=%s, name=%s]", id, name);
	}

	
	
	
}