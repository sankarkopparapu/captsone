package com.entity;
import java.time.LocalDateTime;
import com.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.List;
import java.util.ArrayList;
@Entity
//@Table(name="CourseDetails")
@NamedQueries(value = {  
		@NamedQuery(name="query_get_all_courses",
				query="select c from Course c"),
		@NamedQuery(name="query_get_100_steps_courses",
		query="select c from Course c where name like '%100 steps'")
		
})


//@NamedQuery(name="query_get_all_courses",query="select c from Course c")
//@NamedQuery(name="query_get_100_steps_courses",query="select c from Course c where name like '%100 steps'")

public class Course {

	@Id
	@GeneratedValue
	private Long id;

	@Column(nullable=false)
	private String name;
	
	@OneToMany(mappedBy="course")//,fetch=FetchType.EAGER)
	private List<Review> reviews =new ArrayList<>();
	
	@ManyToMany(mappedBy="courses")
    private List<Student> students = new ArrayList<>();
	
	@UpdateTimestamp
	private LocalDateTime lastUpdatedDate;
	@CreationTimestamp
	private LocalDateTime createdDate;

	protected Course() {
	}

	
	public List<Review> getReviews() {
		return reviews;
	}

	public void addReview(Review review) {
		this.reviews.add(review);
	}
	public void removeReview(Review review) {
		this.reviews.remove (review);
	}

	public List<Student> getStudents() {
		return students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}
	public Course(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getId() {
		return id;
	}
	@Override
	public String toString() {
		return String.format("\nCourse [id=%s, name=%s]", id, name);
	}

	/*insert into student_course(student_id,course_id) 
	values(20001,10001);
	insert into student_course(student_id,course_id) 
	values(20002,10001);
	insert into student_course(student_id,course_id) 
	values(20003,10001);
	insert into student_course(student_id,course_id) 
	values(20001,10003);*/
	
	
}