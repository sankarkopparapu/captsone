package com.entity;

import jakarta.persistence.Entity;

@Entity
public class PartTimeEmployee extends Employee{

}
