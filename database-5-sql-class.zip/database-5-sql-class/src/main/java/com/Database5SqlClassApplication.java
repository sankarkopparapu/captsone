package com;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.entity.Course;
import com.entity.Review;
import com.entity.Student;
import com.*;
import com.repository.CourseRepository;
import com.repository.StudentRepository;
import java.util.ArrayList;
@SpringBootApplication
public class Database5SqlClassApplication implements CommandLineRunner{
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Autowired
	private StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(Database5SqlClassApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		//courseRepository.addHardcodedReviewsForCourse(); 
	/*	List<Review> reviews= new ArrayList<>();
		reviews.add(new Review("5","Great Hands-on Stuff."));
		reviews.add(new Review("5","Hatsoff"));
		courseRepository.addReviewsForCourse(10003L,reviews);*/
		//studentRepository.saveStudentWithPassport();
		
		//studentRepository.insertHardcodedStudentAndCourse();
		studentRepository.insertStudentAndCourse(new Student("siva"),
				new Course("Microservices in 100 steps") );
		//Course course = repository.findById(10001L);
		//logger.info("Course 10001 -> {}", course);
		//repository.save(new Course("Microservices in 100 steps"));

		//repository.playWithEntityManager();
		/*SELECT * FROM STUDENT_COURSE ,STUDENT,COURSE
		WHERE STUDENT_COURSE.STUDENT_ID=STUDENT.ID AND 
		STUDENT_COURSE.COURSE_ID=COURSE_ID;*/
	}
}